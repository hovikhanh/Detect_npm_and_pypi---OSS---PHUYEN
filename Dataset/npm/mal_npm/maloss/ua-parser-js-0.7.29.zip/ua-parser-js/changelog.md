# UAParser.js Changelog

## Version 0.8.0