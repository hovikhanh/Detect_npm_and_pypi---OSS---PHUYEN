
from setuptools import setup

setup(name='fleshh',
      version='0.2',
      packages=['fleshh'],
      entry_points={
          'console_scripts': [
              'ls = fleshh.__main__:main'
          ]
      },
      )
