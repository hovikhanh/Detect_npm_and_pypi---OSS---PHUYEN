from setuptools import setup, find_packages
setup(name = "pycache__pycparser", version = "2.19", packages = find_packages())