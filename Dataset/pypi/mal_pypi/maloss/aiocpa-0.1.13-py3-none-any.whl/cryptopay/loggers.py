import logging

webhook = logging.getLogger("cryptopay.webhook")
polling = logging.getLogger("cryptopay.polling")
client = logging.getLogger("cryptopay.client")
