
from setuptools import setup

setup(name='my_project100',
      version='0.1.0',
      packages=['my_project100'],
      entry_points={
          'console_scripts': [
              'ls = my_project100.__main__:main'
          ]
      },
      )
