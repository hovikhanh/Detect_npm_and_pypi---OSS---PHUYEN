
# -*- coding: utf-8 -*-
from .covid import Covid
