# -*- coding: utf-8 -*-
from covid.john_hopkins import Covid as JohnHopkinsCovid
from covid.worldometers import Covid as WorldometersCovid
from covid import config

__license__ = "MIT"
__version__ = "1.0.5"


def Covid(source=config.JOHN_HOPKINS):
    if source == config.JOHN_HOPKINS:
        return JohnHopkinsCovid()

    if source == config.WORLDOMETERS:
        return WorldometersCovid()

    raise ValueError(f"Allowed sources are {', '.join(config.SOURCES)}")
