#!/usr/bin/env python

INSTALLED_APPS = [
    'github_templates_variables',
]

