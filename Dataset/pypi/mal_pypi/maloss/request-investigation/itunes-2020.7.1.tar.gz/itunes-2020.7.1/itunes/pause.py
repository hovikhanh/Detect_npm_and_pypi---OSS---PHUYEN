#!/usr/bin/env python
import itunes

if __name__ == "__main__":
    itunes.pause()
