#!/usr/bin/env python
"""macOS afk time in days"""
import mac_afk


def cli():
    print(mac_afk.days())


if __name__ == "__main__":
    cli()
