#!/usr/bin/env python
import django
from django_admin_parent_filter import ParentFilter
import public
try:
    from wagtail.core.models import Page
except django.core.exceptions.AppRegistryNotReady:
    pass


@public.add
class ParentFilter(ParentFilter):
    """Wagtail admin Page parent filter"""
    title = None
    model = None
    parent_model = None
    count = False
    items = []
    depth = -1

    __readme__ = dict(
        title="title",
        model="queryset model",
        parent_model="filter model",
        count="show childs count. default - False",
        items="initial items"
    )

    def get_children(self, parent):
        """return a list of children"""
        return parent.get_children().type(self.parent_model)

    @property
    def top_instance(self):
        """return top instance. model first_common_ancestor"""
        return Page.objects.type(self.model).first_common_ancestor()

    def get_postfix(self):
        """return postfix string (childs count)"""
        if self.count:
            count = self.model.objects.descendant_of(self.instance).count()
            return " (%s)" % count

    def queryset(self, request, queryset):
        """return queryset object"""
        if self.value() is None:
            return queryset
        parent = Page.objects.get(pk=self.value())
        return self.model.objects.descendant_of(parent)
