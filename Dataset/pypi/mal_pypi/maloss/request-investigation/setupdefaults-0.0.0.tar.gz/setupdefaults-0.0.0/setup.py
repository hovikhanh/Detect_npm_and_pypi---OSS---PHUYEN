from distutils.core import setup

setup(name="setupdefaults", version="0.0.0")
