from distutils.core import setup

setup(name="mac-input", version="0.0.0",classifiers=['Development Status :: 1 - Planning'])
