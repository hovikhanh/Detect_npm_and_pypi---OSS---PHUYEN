from distutils.core import setup

setup(name="lowercasedict", version="0.0.0")
