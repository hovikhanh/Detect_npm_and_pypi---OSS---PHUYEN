#!/usr/bin/env python
import github_blog.api

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.contenttypes',
    'django_summernote',
    "taggit",
    "github_blog",
]
