#!/usr/bin/env python
from django.apps import AppConfig


class DjangoMakeSuperUserConfig(AppConfig):
    name = 'django_makesuperuser'
