from distutils.core import setup

setup(name="var", version="0.0.0",classifiers=['Development Status :: 1 - Planning'])
