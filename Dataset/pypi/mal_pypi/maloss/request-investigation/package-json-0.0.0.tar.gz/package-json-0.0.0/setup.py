from distutils.core import setup

setup(name="package-json", version="0.0.0")
