<!--
https://pypi.org/project/readme-generator/
https://pypi.org/project/python-readme-generator/
https://pypi.org/project/django-readme-generator/
-->

[![](https://img.shields.io/pypi/pyversions/django-startapps-command.svg?longCache=True)](https://pypi.org/project/django-startapps-command/)

#### Installation
```bash
$ [sudo] pip install django-startapps-command
```

#### `settings.py`
```python
if DEBUG:
    INSTALLED_APPS = ["django_startapps_command"]+INSTALLED_APPS
```

`APPS_DIR`, optional. `apps/` by default
```python
APPS_DIR = 'path/to/apps'
```

#### Commands
command|`help`
-|-
`python manage.py startapps` |startapp for every folder in apps/

#### Examples
```bash
apps/
apps/app1/
apps/app2/
```

```bash
$ python manage.py startapps
```

```bash
apps/app1/__init__.py
apps/app1/admin.py
...
apps/app2/__init__.py
apps/app2/admin.py
...
```

<p align="center">
    <a href="https://pypi.org/project/django-readme-generator/">django-readme-generator</a>
</p>