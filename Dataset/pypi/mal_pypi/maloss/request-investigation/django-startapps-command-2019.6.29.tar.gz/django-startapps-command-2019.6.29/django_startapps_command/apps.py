#!/usr/bin/env python
from django.apps import AppConfig


class DjangoStartappsCommandConfig(AppConfig):
    name = 'django_startapps_command'
