# !/usr/bin/env python
from django.conf import settings
from django.core import management
from django.core.management.base import BaseCommand
import os


class Command(BaseCommand):
    help = 'startapp for every folder in apps/'

    def add_arguments(self, parser):
        super(Command, self).add_arguments(parser)
        parser.add_argument('--template', dest='template', default=None)

    def handle(self, *args, **options):
        template = options.get('template')
        APPS_DIR = getattr(settings, "APPS_DIR", "apps")
        if not os.path.exists(APPS_DIR):
            print("SKIP: %s NOT EXISTS" % APPS_DIR)
            return
        __init__ = os.path.join(APPS_DIR, "__init__.py")
        if not os.path.exists(__init__):
            open(__init__,"w").write("")
        for l in filter(lambda l:l not in ["__pycache__"],os.listdir(APPS_DIR)):
            app_name = l.capitalize()
            app_path = os.path.join(APPS_DIR, l)
            __init__ = os.path.join(app_path, "__init__.py")
            if os.path.isdir(app_path) and not os.path.exists(__init__):
                args = ['startapp',app_name, app_path]
                if template:
                    args = ['startapp', "--template=%s" % template,app_name, app_path]
                management.call_command(*args, verbosity=0)
