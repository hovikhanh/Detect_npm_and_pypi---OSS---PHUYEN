from distutils.core import setup

setup(name="screensaver", version="0.0.0")
