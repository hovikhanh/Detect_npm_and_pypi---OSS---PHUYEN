from distutils.core import setup

setup(name="sublime-text", version="0.0.0",classifiers=['Development Status :: 1 - Planning'])
