from distutils.core import setup

setup(name="python-tests", version="0.0.0")
