from distutils.core import setup

setup(name="ps", version="0.0.0")
