from django.apps import AppConfig


class LaunchPlistConfig(AppConfig):
    name = 'django_launchd'
