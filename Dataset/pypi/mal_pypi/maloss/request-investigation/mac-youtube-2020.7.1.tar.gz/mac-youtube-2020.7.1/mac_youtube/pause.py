#!/usr/bin/env python
"""pause youtube videos"""
import mac_youtube


def _cli():
    mac_youtube.pause()


if __name__ == "__main__":
    _cli()
