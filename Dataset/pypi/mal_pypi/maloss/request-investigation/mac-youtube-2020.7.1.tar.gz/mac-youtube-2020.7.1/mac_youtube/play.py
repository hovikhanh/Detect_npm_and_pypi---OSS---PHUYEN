#!/usr/bin/env python
"""continue play youtube video"""
import mac_youtube


def _cli():
    mac_youtube.play()


if __name__ == "__main__":
    _cli()
