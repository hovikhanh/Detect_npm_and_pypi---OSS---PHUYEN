#!/usr/bin/env python
from django.apps import AppConfig


class DjangoPostgresCreatedbConfig(AppConfig):
    name = 'django_postgres_createdb'
