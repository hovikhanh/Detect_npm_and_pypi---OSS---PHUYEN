#!/usr/bin/env python
import launchd_env.plist

"""
<key>EnvironmentVariables</key>
<dict>
     <key>PATH</key>
     <string>...</string>
</dict>
"""
