#!/usr/bin/env python
"""set Finder tag. `red` - not empty error logs, `none` - other logs"""
import mac_logs

if __name__ == "__main__":
    mac_logs.tag()
