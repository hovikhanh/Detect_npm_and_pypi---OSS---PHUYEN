#!/usr/bin/env python
from badges.badge import Badge
from badges.bettercodehub import Bettercodehub
from badges.circleci import Circleci
from badges.codeclimate import Codeclimate
from badges.codecov import Codecov
from badges.codefactor import Codefactor
from badges.scrutinizer import Scrutinizer
from badges.semaphoreci import Semaphoreci
from badges.sonarcloud import Sonarcloud
from badges.travis import Travis
