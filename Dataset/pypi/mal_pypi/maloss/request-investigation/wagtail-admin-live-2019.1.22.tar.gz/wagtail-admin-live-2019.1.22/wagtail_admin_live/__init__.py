#!/usr/bin/env pythons
from django.utils.safestring import mark_safe
from wagtail.contrib.modeladmin.options import ModelAdmin
import public

"""
list_display = (..., 'live')        before
list_display = (..., 'get_live')    after
"""

HTML = '<img src="/static/admin/img/icon-yes.svg" alt="True">'


@public.add
class ModelAdmin(ModelAdmin):
    """ModelAdmin replacement"""

    def get_live(self, obj):
        return obj.live
    get_live.boolean = True
    get_live.allow_tags = True
    get_live.admin_order_field = 'live'
    get_live.short_description = mark_safe(HTML)
