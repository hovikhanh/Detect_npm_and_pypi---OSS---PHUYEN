from distutils.core import setup

setup(name="input", version="0.0.0")
