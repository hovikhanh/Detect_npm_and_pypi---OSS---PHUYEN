from distutils.core import setup

setup(name="readmemd", version="0.0.0",classifiers=['Development Status :: 1 - Planning'])
