from distutils.core import setup

setup(name="create-readme", version="0.0.0")
