from setuptools import setup

setup(
    name='django-google-analytics-configuration',
    version='2020.5.30',
    install_requires=[
        'django',
        'django-configurations',
        'setuptools',
    ],
    packages=[
        'django_google_analytics_configuration',
        'django_google_analytics_configuration.templatetags',
    ],
)
