<!--
https://pypi.org/project/readme-generator/
https://pypi.org/project/python-readme-generator/
-->

[![](https://img.shields.io/pypi/pyversions/django-google-analytics-configuration.svg?longCache=True)](https://pypi.org/project/django-google-analytics-configuration/)
[![](https://img.shields.io/pypi/v/django-google-analytics-configuration.svg?maxAge=3600)](https://pypi.org/project/django-google-analytics-configuration/)
[![](https://img.shields.io/badge/License-Unlicense-blue.svg?longCache=True)](https://unlicense.org/)
[![Travis](https://api.travis-ci.org/andrewp-as-is/django-google-analytics-configuration.py.svg?branch=master)](https://travis-ci.org/andrewp-as-is/django-google-analytics-configuration.py/)

#### Installation
```bash
$ [sudo] pip install django-google-analytics-configuration
```

#### Examples
`.env`
```bash
DJANGO_GA_ID="UA-XXXXXXXX-Y"
```

`settings.py`
```python
from django_google_analytics_configuration import GoogleAnalyticsConfiguration

class Prod(GoogleAnalyticsConfiguration,...):
    ...
```

customize
```python
class Prod(GoogleAnalyticsConfiguration,...):
    GA_ID = 'UA-XXXXXXXX-Y'
```

template
```html
{% load google_analytics %}
...
{% google_analytics %}
```

#### Links
+   [django-configurations](https://github.com/jazzband/django-configurations)

<p align="center">
    <a href="https://pypi.org/project/python-readme-generator/">python-readme-generator</a>
</p>