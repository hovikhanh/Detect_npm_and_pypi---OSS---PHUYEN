import os

from configurations import Configuration, values

class GoogleAnalyticsConfiguration(Configuration):
    GA_ID = values.Value(None)

    @classmethod
    def pre_setup(cls):
        super(GoogleAnalyticsConfiguration, cls).pre_setup()
        cls.INSTALLED_APPS+=['django_google_analytics_configuration']

"""
from django_google_analytics_configuration import GoogleAnalyticsConfiguration

class Prod(GoogleAnalyticsConfiguration,...):
    ...
"""

