from distutils.core import setup

setup(name="appify", version="0.0.0")
