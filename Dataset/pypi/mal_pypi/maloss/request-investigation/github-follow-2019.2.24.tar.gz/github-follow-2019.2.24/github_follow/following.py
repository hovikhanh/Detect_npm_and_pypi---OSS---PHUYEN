#!/usr/bin/env python
"""print following users"""
import click
import github_follow

MODULE_NAME = "github_follow.following"
USAGE = 'python -m %s [username]' % MODULE_NAME
PROG_NAME = 'python -m %s' % USAGE


@click.command()
@click.argument('username', required=False)
def _cli(username=None):
    usernames = github_follow.following(username)
    if usernames:
        print("".join(sorted(usernames)))


if __name__ == "__main__":
    _cli()
