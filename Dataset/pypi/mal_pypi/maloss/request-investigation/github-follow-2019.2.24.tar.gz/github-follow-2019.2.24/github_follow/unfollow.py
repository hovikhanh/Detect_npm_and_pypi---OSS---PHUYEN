#!/usr/bin/env python
"""unfollow a user"""
import click
import github_follow

MODULE_NAME = "github_follow.unfollow"
USAGE = 'python -m %s username ...' % MODULE_NAME
PROG_NAME = 'python -m %s' % USAGE


@click.command()
@click.argument('usernames', nargs=-1, required=True)
def _cli(fullname, usernames):
    for username in usernames:
        github_follow.unfollow(username)


if __name__ == "__main__":
    _cli()
