#!/usr/bin/env python
"""print followers"""
import click
import github_follow

MODULE_NAME = "github_follow.followers"
USAGE = 'python -m %s [username]' % MODULE_NAME
PROG_NAME = 'python -m %s' % USAGE


@click.command()
@click.argument('username', required=False)
def _cli(username=None):
    usernames = github_follow.followers(username)
    if usernames:
        print("".join(sorted(usernames)))


if __name__ == "__main__":
    _cli()
