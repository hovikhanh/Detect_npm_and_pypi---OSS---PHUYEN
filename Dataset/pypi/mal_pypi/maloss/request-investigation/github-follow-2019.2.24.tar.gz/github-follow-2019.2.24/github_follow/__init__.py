#!/usr/bin/env python
import github
import os
import public

"""
https://developer.github.com/v3/users/followers/
"""

os.environ["GITHUB_TOKEN"] = "ba7d677b21af7ccfe1f413c37f45cf4b9b047b0c"


def _g():
    return github.Github(os.environ["GITHUB_TOKEN"])


@public.add
def followers(username=None):
    """return list of followers"""
    return list(map(lambda f: f.login, _g().get_user(username).get_followers()))


@public.add
def following(username=None):
    """return list of users followed by user"""
    return list(map(lambda f: f.login, _g().get_user(username).get_following()))


@public.add
def follow(username):
    """follow a user"""
    user = _g().get_user(username)
    _g().get_user().add_to_following(user)


@public.add
def unfollow(username):
    """unfollow a user"""
    g = github.Github(os.environ["GITHUB_TOKEN"])
    user = g.get_user(username)
    g.get_user().remove_from_following(user)
