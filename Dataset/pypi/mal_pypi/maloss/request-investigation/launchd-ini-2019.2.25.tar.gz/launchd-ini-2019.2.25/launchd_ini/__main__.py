#!/usr/bin/env python
"""create launchd.plist files from ini file(s)"""
import click
import launchd_ini

MODULE_NAME = "launchd_ini"
USAGE = 'python -m %s path ...' % MODULE_NAME
PROG_NAME = 'python -m %s' % USAGE


@click.command()
@click.argument('paths', nargs=-1, required=True)
def _cli(paths):
    for path in paths:
        launchd_ini.create(path)


if __name__ == "__main__":
    _cli()
