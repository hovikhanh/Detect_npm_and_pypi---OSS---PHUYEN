#!/usr/bin/env python
try:
    from configparser import ConfigParser
except ImportError:
    from ConfigParser import ConfigParser
import os
import plistlib
import launchd_plist
import public


def read(path):
    """return a dictionary with ini file sections"""
    config = ConfigParser()
    with open(path, "r") as f:
        config.read_file(f) if hasattr(config, "read_file") else config.readfp(f)
    result = dict()
    for section in config.sections():
        result[section] = config[section]
    return result


def launchd_key(key):
    """return launchd.plist key"""
    for KEY in launchd_plist.KEYS:
        if KEY.lower() == key.lower():
            return KEY

def launchd_value(value):
    """return launchd.plist value"""
    if value.isdigit():
        return int(value)
    if " " in value:
        return value.split(" ")
    return str(value)

def launchd_data(data):
    result = dict()
    for key, value in dict(data).items():
        if launchd_key(key):
            result[launchd_key(key)] = launchd_value(value)
    return result


def write(path, data):
    """write data dictionary to a plist file"""
    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))
    if hasattr(plistlib, "dump"):
        plistlib.dump(data, open(path, 'wb'))
    else:
        plistlib.writePlist(data, path)

@public.add
def create(path):
    """create launchd.plist files from ini file"""
    for section_name, section_data in read(path).items():
        data = launchd_data(section_data)
        if data:
            if "Label" not in data:
                data["Label"] = section_name
            write("%s.plist" % section_name,data)
