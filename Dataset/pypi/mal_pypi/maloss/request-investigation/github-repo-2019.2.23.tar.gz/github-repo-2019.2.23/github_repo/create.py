#!/usr/bin/env python
"""create github repo"""
import click
import requests
import github_repo

"""
POST https://api.github.com/user/repos
POST https://api.github.com/orgs/owner/repos
"""

MODULE_NAME = "github_repo.create"
PROG_NAME = 'python -m %s' % MODULE_NAME



def _help(ctx, param, value):
    if value:
        print("usage: %s" % PROG_NAME)
        ctx.exit()


@click.command()
@click.option('--help', is_flag=True, is_eager=False, expose_value=False, callback=_help)
def _cli():
    github_repo.create()


if __name__ == "__main__":
    _cli()
