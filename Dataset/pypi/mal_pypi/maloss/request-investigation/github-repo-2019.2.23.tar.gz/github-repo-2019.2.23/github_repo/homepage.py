#!/usr/bin/env python
"""get/update homepage"""
import click
import github_repo
import public

MODULE_NAME = "github_repo.homepage"
USAGE = 'python -m %s [url]' % MODULE_NAME
PROG_NAME = 'python -m %s' % MODULE_NAME


@public.add
def get():
    """return repo homepage"""
    url = "https://api.github.com/repos/%s" % github_repo.fullname()
    return github_repo.request("get", url).json()["homepage"]


@public.add
def update(url):
    """update repo homepage"""
    data = dict(
        name=github_repo.fullname().split("/")[1],
        homepage=url
    )
    url = "https://api.github.com/repos/%s" % github_repo.fullname()
    github_repo.request("PATCH", url, data).raise_for_status()


@click.command()
@click.argument('url', required=False)
def _cli(url=None):
    if url is not None:
        update(url)
    else:
        url = get()
        if url:
            print(url)


if __name__ == "__main__":
    _cli()
