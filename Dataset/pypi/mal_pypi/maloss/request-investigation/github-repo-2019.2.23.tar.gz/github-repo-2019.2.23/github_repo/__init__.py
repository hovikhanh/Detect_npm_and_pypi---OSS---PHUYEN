#!/usr/bin/env python
import json
import os
import github_repo.remote
import github_repo.topics
import public
import requests


@public.add
def fullname():
    """return fullname (owner/repo) string"""
    url = github_repo.remote.url()
    if "git@" in str(url):
        return str(url).split(":")[1][:-4]
    if "https://github.com" in str(url):
        return str(url).replace("https://github.com/", "")[:-4]


@public.add
def request(method, url, data=None, **kwargs):
    """requests.request"""
    token = os.environ["GITHUB_TOKEN"]
    if "headers" not in kwargs:
        kwargs["headers"] = {}
    kwargs["headers"].update({"Authorization": "Bearer %s" % token})
    if data is not None:
        data = json.dumps(data)
    r = requests.request(method, url, data=data, **kwargs)
    if r.status_code in [401]:
        r.raise_for_status()
    return r


@public.add
def create():
    """create github repo"""
    _fullname = fullname()
    if requests.get("https://github.com/%s" % _fullname) == 200:
        """already exists"""
        return
    data = dict(name=_fullname.split("/")[1])
    url = "https://api.github.com/user/repos"
    request("POST", url, data=data)
