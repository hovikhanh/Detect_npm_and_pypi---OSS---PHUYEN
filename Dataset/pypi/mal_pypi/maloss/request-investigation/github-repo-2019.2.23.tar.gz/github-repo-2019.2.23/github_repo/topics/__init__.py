#!/usr/bin/env python
import github_repo
import values
import public

"""
https://developer.github.com/v3/repos/#replace-all-topics-for-a-repository
application/vnd.github.mercy-preview+json
GET /repos/:owner/:repo/topics
PUT /repos/:owner/:repo/topics
"""


def _request(method, data=None):
    headers = {'Accept': "application/vnd.github.mercy-preview+json"}
    url = "https://api.github.com/repos/%s/topics" % github_repo.fullname()
    return github_repo.request(method, url, data, headers=headers)


@public.add
def get():
    """return topics list"""
    return _request("get").json()["names"]


@public.add
def add(topics):
    """add topics"""
    data = {"names": get() + values.get(topics)}
    _request("PUT", data=data)


@public.add
def update(topics):
    """replace all topics"""
    data = {"names": list(sorted(values.get(topics)))}
    _request("PUT", data=data)


def rm():
    """remove all topics"""
    update([])
