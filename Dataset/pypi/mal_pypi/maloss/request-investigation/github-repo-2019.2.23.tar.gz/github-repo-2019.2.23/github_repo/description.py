#!/usr/bin/env python
"""get/update description"""
import click
import github_repo
import public

MODULE_NAME = "github_repo.description"
USAGE = 'python -m %s [description]' % MODULE_NAME
PROG_NAME = 'python -m %s' % USAGE


@public.add
def get():
    """return repo description"""
    url = "https://api.github.com/repos/%s" % github_repo.fullname()
    return github_repo.request("get", url).json()["description"]


@public.add
def update(description):
    """update repo description"""
    data = dict(
        name=github_repo.fullname().split("/")[1],
        description=description
    )
    url = "https://api.github.com/repos/%s" % github_repo.fullname()
    github_repo.request("PATCH", url, data).raise_for_status()


@click.command()
@click.argument('description', required=False)
def _cli(description=None):
    if description is not None:
        update(description)
    else:
        description = get()
        if description:
            print(description)


if __name__ == "__main__":
    _cli()
