#!/usr/bin/env python
"""open github repo in browser"""
import click
import sys
import webbrowser
import github_repo

MODULE_NAME = "github_repo.browse"
PROG_NAME = 'python -m %s' % MODULE_NAME


def browse():
    fullname = github_repo.fullname()
    if fullname:
        url = "https://github.com/%s" % fullname
        print(url)
        webbrowser.open(url)
        return
    else:
        print("git remote not exists")
        sys.exit(1)


def _help(ctx, param, value):
    if value:
        print("usage: %s" % PROG_NAME)
        ctx.exit()


@click.command()
@click.option('--help', is_flag=True, is_eager=False, expose_value=False, callback=_help)
def _cli():
    browse()


if __name__ == "__main__":
    _cli()
