#!/usr/bin/env python
"""repository topics"""
import click
import github_repo

MODULE_NAME = "github_repo.topics.update"
USAGE = 'python -m %s topic ...' % MODULE_NAME
PROG_NAME = 'python -m %s' % MODULE_NAME


@click.command()
@click.argument('topics', nargs=-1)
def _cli(topics):
    github_repo.topics.update(topics)


if __name__ == "__main__":
    _cli(prog_name=PROG_NAME)
