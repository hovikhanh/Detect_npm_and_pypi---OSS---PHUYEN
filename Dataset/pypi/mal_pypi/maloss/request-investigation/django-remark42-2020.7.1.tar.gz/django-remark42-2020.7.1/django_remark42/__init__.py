#!/usr/bin/env python

INSTALLED_APPS = [
    'django_remark42',
]
