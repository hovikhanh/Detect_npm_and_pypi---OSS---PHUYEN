#!/usr/bin/env python
import mac_app_env.plist

"""
<app>/Contents/Info.plist

<key>LSEnvironment</key>
<dict>
     <key>PATH</key>
     <string>...</string>
</dict>
"""
