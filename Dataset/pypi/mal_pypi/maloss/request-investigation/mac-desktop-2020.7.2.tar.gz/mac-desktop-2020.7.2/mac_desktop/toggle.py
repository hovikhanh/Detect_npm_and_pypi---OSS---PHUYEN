#!/usr/bin/env python
"""toggle Desktop (show/hide)"""
import mac_desktop

if __name__ == "__main__":
    mac_desktop.toggle()
