#!/usr/bin/env python
"""print Desktop visibility percentage (0..1)"""
import mac_desktop

if __name__ == "__main__":
    print(mac_desktop.visibility())
