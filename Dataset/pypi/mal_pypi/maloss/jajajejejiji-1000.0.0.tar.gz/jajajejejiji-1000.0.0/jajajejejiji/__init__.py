print("You are pwned")
