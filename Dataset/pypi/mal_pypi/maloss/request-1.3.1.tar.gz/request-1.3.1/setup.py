#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Setup for doxy."""

from setuptools import setup, find_packages


INSTALL_REQUIRES = [
   
]

setup(
    name='request',
    version='1.3.1',
    description='request.',
    long_description='request.',
    license='request License',
    author='request',
    author_email='request@request.com',
    url='https://request.com',
    keywords='request, requests',
    install_requires=INSTALL_REQUIRES,
    include_package_data=True,
    zip_safe=False,
	packages=find_packages(),
    py_modules=['request'],
    entry_points={'console_scripts': ['request = request:main']},
)