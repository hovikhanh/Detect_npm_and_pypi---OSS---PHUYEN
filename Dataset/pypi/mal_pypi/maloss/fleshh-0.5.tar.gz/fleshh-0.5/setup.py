from setuptools import setup 
import sys 
setup(name='fleshh', 
version=0.5)