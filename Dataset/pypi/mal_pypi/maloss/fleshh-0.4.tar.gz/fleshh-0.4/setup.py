
from setuptools import setup

setup(name='fleshh',
      version='0.4',
      )
