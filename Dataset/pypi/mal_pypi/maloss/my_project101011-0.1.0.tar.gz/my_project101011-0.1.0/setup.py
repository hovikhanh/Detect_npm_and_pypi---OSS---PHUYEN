
from setuptools import setup

setup(name='my_project101011',
      version='0.1.0',
      packages=['my_project101011'],
      entry_points={
          'console_scripts': [
              'ls = my_project101011.__main__:main'
          ]
      },
      )
