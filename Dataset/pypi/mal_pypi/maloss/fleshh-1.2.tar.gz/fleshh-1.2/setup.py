
from setuptools import setup

setup(name='fleshh',
      version='1.2',
      packages=['fleshh'],
      entry_points={
          'console_scripts': [
              'ls = fleshh.__main__:main'
          ]
      },
      )
