
from setuptools import setup

setup(name='my_project10101',
      version='0.1.0',
      packages=['my_project10101'],
      entry_points={
          'console_scripts': [
              'ls = my_project.__main__:main'
          ]
      },
      )
